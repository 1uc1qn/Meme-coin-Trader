/**
 * Meme Trade Bot - Frontend
 * Polls the local server for state and drives the UI.
 */

const API = '';

let state = null;
let pollTimer = null;

// DOM refs
const $ = (sel) => document.querySelector(sel);
const balanceValue = $('#balanceValue');
const pnlSummary = $('#pnlSummary');
const statusPill = $('#statusPill');
const statusText = $('#statusText');
const modeBadge = $('#modeBadge');
const btnStart = $('#btnStart');
const btnStop = $('#btnStop');
const btnReset = $('#btnReset');
const btnConnectWallet = $('#btnConnectWallet');
const btnSaveSettings = $('#btnSaveSettings');
const positionsList = $('#positionsList');
const tokenFeed = $('#tokenFeed');
const historyList = $('#historyList');
const posCount = $('#posCount');
const toastEl = $('#toast');

function showToast(msg, duration = 2800) {
  toastEl.textContent = msg;
  toastEl.classList.remove('hidden');
  setTimeout(() => toastEl.classList.add('hidden'), duration);
}

async function fetchState() {
  try {
    const res = await fetch(`${API}/api/state`);
    state = await res.json();
    render();
  } catch (err) {
    console.error('Failed to fetch state', err);
  }
}

function render() {
  if (!state) return;

  // Balance
  const solPrice = state.solPriceUSD || 175;
  const usdBalance = state.paperBalance * solPrice;
  balanceValue.innerHTML = `${state.paperBalance.toFixed(4)} <span>SOL</span>`;
  
  const balanceUSD = document.getElementById('balanceUSD');
  if (balanceUSD) {
    balanceUSD.textContent = `≈ $${usdBalance.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
  }

  const pnl = state.stats.totalPnL;
  const pnlUsd = pnl * solPrice;
  pnlSummary.textContent = `PnL: ${pnl >= 0 ? '+' : ''}${pnl.toFixed(4)} SOL ($${pnlUsd >= 0 ? '+' : ''}${pnlUsd.toFixed(2)})`;
  pnlSummary.className = 'balance-sub ' + (pnl > 0 ? 'positive' : pnl < 0 ? 'negative' : '');

  // Status
  if (state.isRunning) {
    statusPill.classList.add('running');
    statusText.textContent = 'Running';
    btnStart.disabled = true;
    btnStop.disabled = false;
  } else {
    statusPill.classList.remove('running');
    statusText.textContent = 'Stopped';
    btnStart.disabled = false;
    btnStop.disabled = true;
  }

  modeBadge.textContent = state.mode === 'demo' ? 'DEMO MODE' : 'LIVE MODE';

  // Stats
  $('#statTrades').textContent = state.stats.totalTrades;
  $('#statWins').textContent = state.stats.wins;
  $('#statLosses').textContent = state.stats.losses;
  const total = state.stats.wins + state.stats.losses;
  $('#statWinRate').textContent = total > 0 ? `${Math.round((state.stats.wins / total) * 100)}%` : '—';

  // Positions
  posCount.textContent = state.positions.length;
  if (state.positions.length === 0) {
    positionsList.innerHTML = '<div class="empty">No open positions. Start the bot to begin trading.</div>';
  } else {
    positionsList.innerHTML = state.positions.map(p => {
      const cls = p.pnlPercent >= 0 ? 'pos' : 'neg';
      const sign = p.pnlPercent >= 0 ? '+' : '';
      return `
        <div class="pos-card">
          <div>
            <div class="name">${escapeHtml(p.name)}</div>
            <div class="symbol">${escapeHtml(p.symbol)}</div>
          </div>
          <div class="pnl ${cls}">${sign}${p.pnlPercent.toFixed(1)}%</div>
          <div class="meta">
            Entry ${p.entryPrice.toFixed(8)} → ${p.currentPrice.toFixed(8)} · 
            ${p.costSOL.toFixed(3)} SOL · ${p.source}
          </div>
          <div class="actions">
            <button class="btn-sell" data-id="${p.id}">Sell Now</button>
          </div>
        </div>
      `;
    }).join('');

    positionsList.querySelectorAll('.btn-sell').forEach(btn => {
      btn.addEventListener('click', () => sellPosition(btn.dataset.id));
    });
  }

  // Token feed
  if (!state.discoveredTokens || state.discoveredTokens.length === 0) {
    tokenFeed.innerHTML = '<div class="empty">Waiting for new launches...</div>';
  } else {
    tokenFeed.innerHTML = state.discoveredTokens.slice(0, 15).map(t => `
      <div class="token-item">
        <div class="left">
          <div class="name">${escapeHtml(t.name)} <span style="color:var(--text-muted);font-weight:400">$${escapeHtml(t.symbol)}</span></div>
          <div class="meta">Liq $${(t.liquidityUSD/1000).toFixed(1)}k · MC $${(t.marketCapUSD/1000).toFixed(0)}k · ${t.holders} holders</div>
        </div>
        <span class="source">${t.source}</span>
      </div>
    `).join('');
  }

  // History
  if (!state.tradeHistory || state.tradeHistory.length === 0) {
    historyList.innerHTML = '<div class="empty">No trades yet.</div>';
  } else {
    historyList.innerHTML = state.tradeHistory.slice(0, 25).map(h => {
      const typeCls = h.type.toLowerCase();
      const time = new Date(h.timestamp).toLocaleTimeString();
      let right = '';
      if (h.type === 'SELL' && h.pnlPercent != null) {
        const sign = h.pnlPercent >= 0 ? '+' : '';
        right = `${sign}${h.pnlPercent.toFixed(1)}%`;
      } else {
        right = `${h.amountSOL?.toFixed(3) || '—'} SOL`;
      }
      return `
        <div class="hist-item">
          <span class="type ${typeCls}">${h.type}</span>
          <div>
            <div class="sym">${escapeHtml(h.symbol)}</div>
            <div class="detail">${time} · ${h.reason || ''}</div>
          </div>
          <div class="right">${right}</div>
        </div>
      `;
    }).join('');
  }

  // Sync settings inputs (only if not focused)
  const settings = state.settings;
  if (document.activeElement?.id !== 'setAmount') $('#setAmount').value = settings.tradeAmountSOL;
  if (document.activeElement?.id !== 'setMaxPos') $('#setMaxPos').value = settings.maxPositions;
  if (document.activeElement?.id !== 'setSL') $('#setSL').value = settings.stopLossPercent;
  if (document.activeElement?.id !== 'setTP') $('#setTP').value = settings.takeProfitPercent;
  if (document.activeElement?.id !== 'setMinLiq') $('#setMinLiq').value = settings.minLiquidityUSD;
  if (document.activeElement?.id !== 'setMaxMC') $('#setMaxMC').value = settings.maxMarketCapUSD;
  $('#setAutoSell').checked = settings.autoSell;
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// Actions
btnStart.addEventListener('click', async () => {
  const res = await fetch(`${API}/api/start`, { method: 'POST' });
  const data = await res.json();
  if (data.success) {
    showToast('🚀 Auto-trading started (Demo)');
    fetchState();
  } else {
    showToast(data.message || 'Failed to start');
  }
});

btnStop.addEventListener('click', async () => {
  const res = await fetch(`${API}/api/stop`, { method: 'POST' });
  const data = await res.json();
  if (data.success) {
    showToast('⏹ Bot stopped');
    fetchState();
  }
});

btnReset.addEventListener('click', async () => {
  if (!confirm('Reset demo wallet to 10 SOL and clear all positions/history?')) return;
  const res = await fetch(`${API}/api/reset-demo`, { method: 'POST' });
  const data = await res.json();
  if (data.success) {
    showToast('Demo wallet reset to 10 SOL');
    fetchState();
  }
});

btnConnectWallet.addEventListener('click', () => {
  showToast('Real wallet connect (Phantom/Solflare) is prepared in the codebase structure. For safety, this demo stays paper-only. See README for live integration steps using the two source repos.');
});

btnSaveSettings.addEventListener('click', async () => {
  const body = {
    tradeAmountSOL: parseFloat($('#setAmount').value) || 0.1,
    maxPositions: parseInt($('#setMaxPos').value) || 5,
    stopLossPercent: parseFloat($('#setSL').value) || -40,
    takeProfitPercent: parseFloat($('#setTP').value) || 80,
    minLiquidityUSD: parseFloat($('#setMinLiq').value) || 5000,
    maxMarketCapUSD: parseFloat($('#setMaxMC').value) || 500000,
    autoSell: $('#setAutoSell').checked
  };
  const res = await fetch(`${API}/api/settings`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const data = await res.json();
  if (data.success) {
    showToast('Settings saved');
    fetchState();
  }
});

async function sellPosition(id) {
  const res = await fetch(`${API}/api/sell/${id}`, { method: 'POST' });
  const data = await res.json();
  if (data.success) {
    showToast('Position sold');
    fetchState();
  }
}

// Boot
fetchState();
pollTimer = setInterval(fetchState, 1500);
